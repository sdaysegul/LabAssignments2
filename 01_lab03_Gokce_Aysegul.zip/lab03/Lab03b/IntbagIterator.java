import java.util.Iterator;
/**
 * __An interface like iterator but for intbag types___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */ 
public class IntbagIterator implements Iterator
{
   //properties
   IntBag aBag;
   int index;
   
   //contructor
   public IntbagIterator ( IntBag bag) {
      aBag = bag;
      index = 0;
   }
   
   //methods
   
   /**
    * A method to get the next element of the collection
    * @return next element
    */
   public Object next() {
      Integer temp = aBag.bag[index];
      index = index + 2;
      return temp;
   }
   
   /**
    * A method to check if the collection has one more element or not
    * @return true or false
    */
   public boolean hasNext() {
      if ( index < aBag.valid) {
         return true;
      } 
      else {
         return false;
      }
   }
}