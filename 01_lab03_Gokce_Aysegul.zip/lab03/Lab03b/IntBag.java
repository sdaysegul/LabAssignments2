import java.util.Iterator;
/**
 * __A class to hold intbags___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */ 
public class IntBag implements IntIterator{
   //properties
   int[] bag;
   int valid;
   int index;
   
   //constructors
   public IntBag() {
      valid = 0;
      bag = new int[valid];
      index = 0;
   }
   
   public IntBag(int theValid) {
      valid = theValid;
      bag = new int[valid];
      index = 0;
   }
   
   //methods
   
   /**
    * A method to add elemnt to the bag
    * @param the value wanted to add
    */
   public void add(int value) {
      int[] newBag;
      newBag = new int[valid+1];
      for(int i = 0; i < valid; i++) {
         newBag[i] = bag[i];
      }
      newBag[valid] = value;
      valid++;
      bag = newBag;
   }
   
   /**
    * A method to add elemnt to the bag at a spesific location
    * @param the value wanted to add
    * @param location
    */
   public void add(int value, int index) {
      int[] newBag;
      newBag = new int[valid+1];
      for(int i = 0; i < valid; i++) {
         if(i < index) {
            newBag[i] = bag[i];
         }
         else {
            newBag[i+1] = bag[i];
         }
      }
      newBag[index] = value;
      valid++;
      bag = newBag;
   }
   
   /**
    * A method to remove elemnt from the bag
    * @param the index of the value wanted to remove
    */
   public void remove(int index) {
      int[] newBag;
      newBag = new int[valid-1];
      for(int i = 0; i < valid; i++) {
         if(i < index) {
            newBag[i] = bag[i];
         }
         else {
            newBag[i] = bag[i+1];
         }
      }
      valid--;
      bag = newBag;
   }
   
   /**
    * A method to check if the elemnet is in the bag or not
    * @param the value
    * @return true or false
    */
   public boolean contains(int value) {
      for(int i = 0; i < valid; i++) {
         if(value == bag[i]){
            return true;
         }
      }
      return false;
   }
   
   /**
    * A method to return string statement of the collection
    * @return collection
    */
   public String toString() {
      String collection = "[";
      for(int i = 0; i < valid; i++) {
         if(i != valid-1) {
            collection += bag[i] + " ";
         }
         else {
            collection += bag[i] + "]";
         }  
      }
      return collection;
   }
   
   /**
    * A method to check method's size
    * @return size of the collection
    */
   public int size() {
      return valid;
   }
   
   /**
    * A method to get the value at a location
    * @param index
    * @return value
    */
   public int get(int index) {
      return bag[index];
   }
   
   /**
    * A method to get the index f a value
    * @param the value
    * @return index
    */
   public IntBag findAll(int value) {
      IntBag index = new IntBag(0);
      for(int i=0; i < valid; i++) {
         if(bag[i] == value) {
            index.add(i);
         }
      }
      return index;
   }
   
   
   /**
    * A method to get the next element of the collection
    * @return next element
    */
   public Object next() {
      Integer temp = bag[index];
      index++;
      return temp;
   }
   
   /**
    * A method to check if the collection has one more element or not
    * @return true or false
    */
   public boolean hasNext() {
      if ( index < valid) {
         return true;
      } 
      else {
         return false;
      }
   }
   
   /**
    * A method to get the next integer of the collection
    * @return next integer
    */
   public int nextInt() {
      int temp = bag[index];
      index++;
      return temp;
   }
   
   /**
    * A method to get an instance of IntBagIterator
    * @return an IntBagIterator
    */
   public Iterator iterator() {
      return new IntbagIterator( this);
   }
   
   public class IntbagIterator implements Iterator
{
   //properties
   IntBag aBag;
   int index;
   
   //contructor
   public IntbagIterator ( IntBag bag) {
      aBag = bag;
      index = 0;
   }
   
   //methods
   
   /**
    * A method to get the next element of the collection
    * @return next element
    */
   public Object next() {
      Integer temp = aBag.bag[index];
      index = index + 2;
      return temp;
   }
   
   /**
    * A method to check if the collection has one more element or not
    * @return true or false
    */
   public boolean hasNext() {
      if ( index < aBag.valid) {
         return true;
      } 
      else {
         return false;
      }
   }
}
}