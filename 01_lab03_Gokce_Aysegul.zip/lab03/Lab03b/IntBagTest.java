import java.util.Scanner;

/**
 * __A class to test IntBag class___ 
 * @author __your name___
 * @version __date__
 */ 
public class IntBagTest
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // constants
      
      // variables
      int choice;
      int size;
      IntBag collection = new IntBag();;
      int value = 0;
      int index;
      
      // program code
      do {
         //menu options
         System.out.println("1.Create a new empty collection with a specified maximum capacity (any previous values are lost!)\n"
                               + "2.Read a set of positive values into the collection (use a negative value to indicate all the values have been entered.)\n"
                               +"3.Print the collection of values.\n"
                               +"4.Add a value to the collection of values at a specified location\n"
                               +"5.Remove the value at a specified location from the collection of values\n"
                               +"6.Read a single test value.\n"
                               +"7.Compute the set of locations of the test value within the collection* (see note below).\n"
                               +"8.Print the set of locations.\n"
                               +"9.Quit the program\n");
         choice = scan.nextInt();
         if(choice == 1) {
            System.out.println("Please enter the size you want");
            size = scan.nextInt();
            collection = new IntBag(size);
         }
         
         if(choice == 2) {
            System.out.println("Please enter the values with a negative number");
            value = scan.nextInt();
            for(int i = 0; value > 0; i++) {
               if( i < collection.size()) {
                  collection.add(value, i);
                  value = scan.nextInt();
               }
               else {
                  collection.add(value);
                  value = scan.nextInt();
               }
            }
         }
         
         if(choice == 3) {
            System.out.println(collection.toString());
         }
         
         if(choice == 4) {
            System.out.println("Please first enter the value then index");
            value = scan.nextInt();
            index = scan.nextInt();
            collection.add(value,index);
         }
         
         if(choice == 5) {
            System.out.println("Please enter the index of value you want to remove");
            index = scan.nextInt();
            collection.remove(index);
            
         }
         
         if(choice == 6) {
             System.out.println("Please enter the test value");
             value = scan.nextInt();
         }
         
         if(choice == 7) {
            collection.findAll(value);
         }
         
         if(choice == 8) {
            System.out.println(collection.findAll(value).toString());
         }
         
      } while(choice != 9);
   }
   
}