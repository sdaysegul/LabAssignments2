import java.util.Scanner;

/**
 * __Prime Number___ 
 * @author __Ay�eg�l G�k�e___
 * @version __10/02/2018__
 */ 
public class PrimeNumbers
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants

      // variables
      IntBag prime;

      // program code
      prime = new IntBag(0);
      boolean isPrime;
      prime.add(2,0);
      for(int i = 3; prime.size() <= 100;  i++) {
         isPrime = true;
         for(int j= 0; j < prime.size(); j++) {
            if(i % prime.get(j) == 0) {
               isPrime = false;
            }
         }
         if(isPrime) {
            prime.add(i);
         }
      }
      System.out.println(prime.toString());
   }

}