import java.util.Iterator;
/**
 * __An interface like iterator but for integer types___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */ 
public interface IntIterator extends Iterator
{
   public int nextInt();
}