import java.util.Scanner;
import java.util.Iterator;
/**
 * __A class to test Iterator class___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */ 
public class TestIterator
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      Iterator i, j;
      IntBag bag;
      
      bag = new IntBag();
      for ( int a = 0; a < 20; a++) {
         bag.add(a);
      }
      i = new IntbagIterator( bag);
      
      while ( i.hasNext() ) 
      {
         System.out.println( i.next() );
         
         //j = new IntbagIterator( bag);
         j = bag.iterator();
         
         while ( j.hasNext() )
         {
            System.out.println( "--" + j.next() );
         }
         
         
      }
      
      IntBag.IntbagIterator iter = bag.new IntbagIterator( bag);
      
      while ( iter.hasNext() ) 
      {
         System.out.println( iter.next() + " �nner test");
        
      }
   }
   
}