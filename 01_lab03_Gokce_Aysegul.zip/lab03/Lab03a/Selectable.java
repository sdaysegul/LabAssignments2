/**
 * __An interface to make sure shape is selectable___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public interface Selectable
{
   public boolean getSelected( );
   public void setSelected( boolean torf);
   public Shape contains( int x, int y);
}