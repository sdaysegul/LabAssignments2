/**
 * __A class for the shape circle___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public class Circle extends Shape implements Selectable
{
   //properties
   double radius;
   int x;
   int y;
   boolean isSelected;
   
   //constructor
   public Circle ( int radius) {
      this.radius = radius;
      x = 0;
      y = 0;
      isSelected = false;
   }
   
   //methods 
   
   /**
    * A method to get the area of the circle
    * @return the area
    */
   public double getArea() {
      return (Math.pow(radius,2) * Math.PI);
   } 
   
   /**
    * A method to return the circle infos to string
    * @return infos about circle
    */
   public String toString() {
      return "A circle with the radius" + radius + ". Is selected?" + getSelected();
   }
   
   /**
    * A method to set the location of the shape
    * @param x-axis of the location to put
    * @param y-axis of the location to put
    */
   public void setLocation(int x, int y) {
      this.x = x;
      this.y = y;
   }
   
   /**
    * A method to get x-axis
    * @return x
    */
   public int getX(){
      return x;
   }
   
   /**
    * A method to get y-axis
    * @return y
    */
   public int getY(){
      return y;
   }
   
   /**
    * A method to check if it is selected
    * @return true or false
    */
   public boolean getSelected(){
      return isSelected;
   }
   
   /**
    * A method to change selcted statu
    */
   public void setSelected( boolean torf){
      isSelected = torf;
   }
   
   /**
    * A method to check shape contains the given point
    * @param x-axis of the point to check
    * @param y-axis of the point to check
    * @return shape object if it includes
    */
   public Shape contains( int a, int b) {
      if ( Math.sqrt( Math.pow((x-a),2) + Math.pow((x-a),2)) <= radius) {
         return  this;
      }
      else
         return null;
   }
   
}