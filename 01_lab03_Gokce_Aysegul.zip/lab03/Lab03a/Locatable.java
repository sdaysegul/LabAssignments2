/**
 * __An interface to make sure shape is locatable___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public interface Locatable 
{
   //methods
   public int getX();
   public int getY();
   public void setLocation(int x, int y);
}
