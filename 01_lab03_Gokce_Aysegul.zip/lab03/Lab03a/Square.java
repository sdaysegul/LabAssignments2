/**
 * __A class for the shape square___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public class Square extends Rectangle
{
   //properties
   double side;
   
   //constructor
   public Square ( int side) {
      super( side, side);
      this.side = side;
   }
   //methods
   public String toString() {
      return "A square with " + side + " sides. Is selected?" + getSelected();
   }
}