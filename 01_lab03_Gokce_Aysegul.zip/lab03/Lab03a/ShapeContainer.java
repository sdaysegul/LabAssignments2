import java.util.ArrayList;
/**
 * __A class to hold shape types in a list___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */


public class ShapeContainer
{
   //properties
   ArrayList<Shape> shapes;
   
   //constructor
   public ShapeContainer() {
      shapes = new ArrayList<Shape>();
   }
   
   //methods
   public void add(Shape s) {
      shapes.add(s);
   }
   
   /**
    * A method to get the total area of the shapes in the collection
    * @return sthe total area
    */
   public double getArea() {
      double area = 0;
      for ( int i = 0; i < shapes.size(); i++) {
         area += shapes.get(i).getArea();
      }
      return area;
   }
   
   /**
    * A method to return the collection into a string
    * @return string of the collection
    */
   public String toString() {
      String s = "";
      for ( int i = 0; i < shapes.size(); i++) {
         s += shapes.get(i).toString() + "\n";
      }
      return s;
   }
   
   /**
    * A method to find the first shape contains given point and to mark it as selected
    * @param x-axis of the point
    * @param y-axis of the point
    */
   public void findContains(int a, int b) {
      int count = 0;
      for ( int i = 0; i < shapes.size() && count == 0; i++){
         Shape thisShape = shapes.get(i);
         if (thisShape instanceof Circle) {
            if ( ((Circle)thisShape).contains( a, b) != null && !((Circle)thisShape).getSelected()) {
               ((Circle)thisShape).setSelected(true);
               count++;
            }
         }
         else {
            if ( ((Rectangle)thisShape).contains( a, b) != null && !(((Rectangle)thisShape).getSelected())) {
               ((Rectangle)thisShape).setSelected(true);
               count++;
            }                  
         }
      }
   }
   
   /**
    * A method to remove selected shapes
    */
   public void removeSelected() {
      for ( int i = 0; i < shapes.size(); i++){
         Shape thisShape = shapes.get(i);
         if (thisShape instanceof Circle) {
            if ( ((Circle)thisShape).getSelected() ) {
               shapes.remove(i);
            }
         }
         else {
            if ( ((Rectangle)thisShape).getSelected() ) {
               shapes.remove(i);
            }                  
         }
         
      }
   }
   
}