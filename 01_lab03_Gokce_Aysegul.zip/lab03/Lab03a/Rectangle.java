/**
 * __A class for the shape rectangle___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public class Rectangle extends Shape implements Selectable
{
   //properties
   double witdh;
   double lenght;
   int x;
   int y;
   boolean isSelected;
   
   //constructor
   
   public Rectangle ( int witdh, int lenght) {
      this.witdh = witdh;
      this.lenght = lenght;
      x = 0;
      y = 0;
      isSelected = false;
   }
   
   //methods
   
   /**
    * A method to get the area of the rectangle
    * @return the area
    */
   public double getArea() {
      return (witdh * lenght);
   }
   
   /**
    * A method to return the rectangle infos to string
    * @return infos about circle
    */
   public String toString() {
      return "A rectangle with " + witdh + " witdh and "+ lenght + " length. Is selected?" + getSelected();
   }
   
   /**
    * A method to set the location of the shape
    * @param x-axis of the location to put
    * @param y-axis of the location to put
    */
   public void setLocation(int x, int y) {
      this.x = x;
      this.y = y;
   }
   
   /**
    * A method to get x-axis
    * @return x
    */
   public int getX(){
      return x;
   }
   
   /**
    * A method to get y-axis
    * @return y
    */
   public int getY(){
      return y;
   }
   
   /**
    * A method to check if it is selected
    * @return true or false
    */
   public boolean getSelected(){
      return isSelected;
   }
   
   /**
    * A method to change selcted statu
    */
   public void setSelected( boolean torf){
      isSelected = torf;
   }
   
   /**
    * A method to check shape contains the given point
    * @param x-axis of the point to check
    * @paramy-axis of the point to check
    * @return shape object if it includes
    */
   public Shape contains( int a, int b) {
      if ( Math.abs(x-a) <= witdh/2 && Math.abs(y-b) <= lenght/2) {
         return  this;
      }
      else
         return null;
   }
   
}