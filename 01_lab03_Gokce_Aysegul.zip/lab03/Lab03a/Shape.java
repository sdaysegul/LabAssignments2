/**
 * __A shape class___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */

public abstract class Shape implements Locatable
{
   //properties
   
   //constructor
   public Shape(){
   }
   
   //methods
   public abstract double getArea();
}