import java.util.Scanner;

/**
 * __A class to test ShapeContainer class___ 
 * @author __Ay�eg�l G�k�e___
 * @version __11/03/2018__
 */ 
public class ShapeTester
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // constants
      
      // variables
      int selection;
      ShapeContainer container;
      int shape;
      int  side1;
      int side2;
      int radius;
      int a;
      int b;
      
      // program code
      container = new ShapeContainer();
      do {
         System.out.println( "Please select what you want to do\n"
                               + "1 --> Add shape to the collection\n"
                               + "2 --> Compute & print the total area\n"
                               + "3 --> Show the list\n"
                               + "4 --> Find and change the first shape that includes a point\n"
                               + "5 --> Remove all selected\n"
                               + "6 --> Reset the collection\n"
                               + "7 --> To exit\n"
                               + "-----------------------------------------");
         selection = scan.nextInt();
         if ( selection == 1) {
            System.out.println( "Please enter the type of the shape you want to add\n"
                                  + "1 --> Circle\n"
                                  + "2 --> Rectangle\n"
                                  + "3 --> Square\n"
                                  + "-----------------------------------------");
            shape = scan.nextInt();
            if ( shape == 1) {
               System.out.println( "Please enter the radius length");
               radius = scan.nextInt();
               container.add( new Circle(radius));
            }
            else if ( shape == 2) {
               System.out.println( "Please enter the lengths of sides");
               side1 = scan.nextInt();
               side2 = scan.nextInt();
               container.add( new Rectangle( side1, side2));
            }
            else if ( shape == 3) {
               System.out.println( "Please enter the length of sides");
               side1 = scan.nextInt();
               container.add( new Square(side1));
            }
            else {
               System.err.println( "Invalid selection");
            }
            
         }
         
         else if ( selection == 2) {
            System.out.println( container.getArea());
         }
         else if ( selection == 3) {
            System.out.println( container.toString());
         }
         else if ( selection == 4) {
            System.out.println( "x-axis");
            a = scan.nextInt();
            System.out.println( "y-axis");
            b = scan.nextInt();
            container.findContains(a,b);
         }
         else if ( selection == 5) {
            container.removeSelected(); 
         }
         else if ( selection == 6) {
            container = new ShapeContainer(); 
         }
         System.out.println( "--------------------------------------------");
      } while( selection != 7);
   }
   
}