/**
 * An array class with some features similar to ArrayList!
 */
public class IntBag {
   //properties
   private int[] bag;
   private int valid;
   
   //constructors
   
    /** 
    * Class constructor.
    */
   public IntBag() {
      valid = 0;
      bag = new int[100];
   }
   
    /** 
    * Class constructor.
    */
   public IntBag(int size) {
      valid = 0;
      bag = new int[size];
   }
    /** 
    * Class constructor.
    */
   public IntBag(IntBag copy) {
      this.valid = copy.valid;
      this.bag = new int[copy.bag.length];
      for(int i = 0; i < this.valid; i++) {
        this.bag[i] = copy.bag[i];
      }
   }
   
   //methods
   
   /**
    * Adds a value at the ending of array.
    * @param value
    */
   public void add(int value) {
     if( valid == bag.length) {
       bag[bag.length-1] = value;
     } else {
        bag[valid] = value;
        valid++;
     }
     
   }
   
   /**
    * Adds a value at a spesific place.
    * @param value
    * @param index
    */
   public void add(int value, int index) {
      for(int i = valid-1; i >= 0; i--) {
         if(i >= index) {
            bag[i+1] = bag[i];
         }
      }
      bag[index] = value;
      valid++;
   }
   
   /**
    * Removes a spesific value at a spesific place.
    * @param index
    */
   public void remove(int index) {
      for(int i = 0; i < valid-1; i++) {
         if(i >= index) {
            bag[i] = bag[i+1];
         }
      }
      bag[valid-1]= 0;
      valid--;
   }
   
   /**
    * Checks whether it contains a spesific value.
    * @param value
    */
   public boolean contains(int value) {
      for(int i = 0; i < valid; i++) {
         if(value == bag[i]){
            return true;
         }
      }
      return false;
   }
   
   /**
    * Returns the array to a string.
    */
   public String toString() {
      String collection = "[";
      for(int i = 0; i < valid; i++) {
         if(i != valid-1) {
            collection += bag[i] + " ";
         }
         else {
            collection += bag[i] + "]";
         }  
      }
      return collection;
   }
   
   /**
    * Sets the tool tip text.
    * @param text  the text of the tool tip
    */
   public int size() {
      return valid;
   }
   
   /**
    * Returns the value at a spesific location.
    * @param index
    */
   public int get(int index) {
      return bag[index];
   }
   
   /**
    * Return all location of a spesific value.
    * @param value
    */
   public IntBag findAll(int value) {
      IntBag index = new IntBag();
      for(int i=0; i < valid; i++) {
         if(bag[i] == value) {
            index.add(i);
         }
      }
      return index;
   }
   
   /**
    * removes the reputations.
    */
   public void removeReputations() {
      IntBag copy = new IntBag(this);
     for(int index: copy.bag) {
         for(int i= 1; i < this.findAll(index).valid; i++) {
            this.remove(this.findAll(index).bag[i]);
         }
      }
   }

   
}