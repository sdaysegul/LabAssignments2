import java.util.Scanner;

/**
 * __Prime Number___ 
 * @author __Ay�eg�l G�k�e___
 * @version __12/02/2018__
 */ 
public class PrimeNumbers
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);

      // constants
      final int SIZE = 100;

      // variables
      IntBag prime;

      // program code
      prime = new IntBag();
      boolean isPrime;
      prime.add(2);
      
      //finds first SIZE number prime numbers
      for(int i = 3; prime.size() < SIZE;  i++) {
         isPrime = true;
         // divides the numbers by the primers found so far
         for(int j= 0; j < prime.size(); j++) {
            if(i % prime.get(j) == 0) {
               isPrime = false;
            }
         }
         if(isPrime) {
            prime.add(i);
         }
      }
      System.out.println(prime.toString());
   }

}