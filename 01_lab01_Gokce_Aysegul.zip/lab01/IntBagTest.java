import java.util.Scanner;

/**
 * __Test class___ 
 * @author __Ay�eg�l G�k�e___
 * @version __12/02/2018__
 */ 
public class IntBagTest
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // constants
      
      // variables
      int choice;
      int size = 0;
      IntBag collection = new IntBag();
      int value = 0;
      int index;
      
      // program code
      do {
        //menu
         System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
         System.out.println("1.Create a new empty collection with a specified maximum capacity (any previous values are lost!)\n"
                               + "2.Read a set of positive values into the collection (use a negative value to indicate all the values have been entered.)\n"
                               +"3.Print the collection of values.\n"
                               +"4.Add a value to the collection of values at a specified location\n"
                               +"5.Remove the value at a specified location from the collection of values\n"
                               +"6.Read a single test value.\n"
                               +"7.Compute the set of locations of the test value within the collection* (see note below).\n"
                               +"8.Print the set of locations.\n"
                               +"9.Quit the program\n"
                               +"10.remove reputations\n");
         choice = scan.nextInt();
         //Creates a new empty collection with a specified maximum
         if(choice == 1) {
            System.out.println("Please enter the size you want");
            size = scan.nextInt();
            collection = new IntBag(size);
         }
         
         //Reads a set of positive values into the collection
         if(choice == 2) {
            System.out.println("Please enter the values with a negative number");
            value = scan.nextInt();
            for(int i = 0; value > 0; i++) {
               if( i < size) {
                  collection.add(value, i);
               }
             value = scan.nextInt();
            }
         }
         
         //Prints the collection of values
         if(choice == 3) {
            System.out.println(collection.toString());
         }
         
         //Adds a value to the collection of values at a specified location
         if(choice == 4) {
            System.out.println("Please first enter the value then index");
            value = scan.nextInt();
            index = scan.nextInt();
            collection.add(value,index);
         }
         
         //Remove the value at a specified location from the collection of values
         if(choice == 5) {
            System.out.println("Please enter the index of value you want to remove");
            index = scan.nextInt();
            collection.remove(index);
            
         }
         
         //Read a single test value
         if(choice == 6) {
             System.out.println("Please enter the test value");
             value = scan.nextInt();
         }
         
         //Computes the set of locations of the test value within the collection
         if(choice == 7) {
            collection.findAll(value);
         }
         
         //Prints the set of locations
         if(choice == 8) {
            System.out.println(collection.findAll(value).toString());
         }
         
         //removes the set of locations
         if(choice == 10) {
            collection.removeReputations();
         }
         
      } while(choice != 9);
   }
   
}