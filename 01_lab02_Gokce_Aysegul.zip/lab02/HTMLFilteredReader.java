/**
 * A class to read content without codes
 * @author __Ay�eg�l G�k�e___
 * @version __26/02/2018__
 */
public class HTMLFilteredReader extends MySimpleURLReader
{
   // properties
   String url;
   
   // constructors
   public HTMLFilteredReader( String theUrl) {
      super( theUrl);
      url = theUrl;
   }
   
   // methods
   /**
    * An override method to get html page content
    * @return htmlcode-free content
    */ 
   @Override
   public String getPageContents() {
      String content = super.getPageContents();
      boolean isTag = false;
      String filtered = "";
      for ( int i = 0; i < content.length(); i++) {
         if ( content.charAt(i)=='<')
            isTag = true;
         else if ( content.charAt(i)=='>')
            isTag= false;
         else if ( !isTag) {
            filtered += content.charAt(i);
         }
      }
      return filtered;
   }
   
   
   /**
    * An override method to get html page content
    * @return htmlcode-free and html character code free content
    */ 
  @Override
   public String getNeatPageContents() {
      String content = getPageContents();
      boolean isTag = false;
      String filtered = "";
      for ( int i = 0; i < content.length(); i++) {
         if ( content.charAt(i)=='&' && content.charAt(i+1)!=' ' )
            isTag = true;
         else if ( content.charAt(i)==';')
            isTag= false;
         else if ( !isTag) {
            filtered += content.charAt(i);
         }
      }
      return filtered;
   }
   
   /**
    * A method to get content in html form
    * @return content with html code
    */ 
   public String getUnfilteredPageContents() {
      return super.getPageContents();
   }
   
    public static void main( String[] args)
   {

      // variables
      HTMLFilteredReader reader;

      // program code
      
      reader = new HTMLFilteredReader("http://www.cs.bilkent.edu.tr/~ozturk/cs102/syllabus.htm");
      System.out.println(reader.getNeatPageContents());
                                      
   }
}