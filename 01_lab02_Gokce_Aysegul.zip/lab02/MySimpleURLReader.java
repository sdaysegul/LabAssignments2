import cs1.SimpleURLReader;
/**
 * A simple Java SimpleURLReader class with some more methods!
 * @author __Ay�eg�l G�k�e___
 * @version __26/02/2018__
 */
public class MySimpleURLReader extends SimpleURLReader
{
   // properties
   String url;
   
   // constructors
   public MySimpleURLReader( String theUrl) {
      super( theUrl);
      url = theUrl;
   }
   
   // methods
   
   
   /**
    * A method to see the url
    * return url
    */ 
   public String getUrl() {
      return url;
   }
   
   /**
    * A method to see name of the file
    * @return name of the file
    */ 
   public String getName() {
      int index = url.length();
      for ( int i= url.length()-1; url.charAt(i)!='/'; i--) {
         index = i;
         if ( index == 0)
            System.out.println( "There is something wrong with url!");
      }
      return url.substring( index, url.length());
   }
   
   /**
    * An override method to see content without bug
    * @return bug-free content
    */ 
   @Override
   public String getPageContents() {
      return super.getPageContents().substring(4);
   }
   
   
   /**
    * A method to get html page content
    * @return htmlcode-free and html character code free content
    */ 
   public String getNeatPageContents() {
      String content = getPageContents();
      boolean isTag = false;
      String filtered = "";
      for ( int i = 0; i < content.length(); i++) {
         if ( super.getPageContents().charAt(i)=='&' && content.charAt(i+1)=='&')
            isTag = true;
         else if ( content.charAt(i)==';')
            isTag= false;
         else if ( !isTag) {
            filtered += content.charAt(i);
         }
      }
      return filtered;
   }
}


