import cs1.SimpleURLReader;

/**
 * __Class to understand simleURLReader___ 
 * @author __Ay�eg�l G�k�e___
 * @version __26/02/2018__
 */ 
public class Lab02a
{
   public static void main( String[] args)
   {
      
      // variables
      SimpleURLReader reader;
      
      // program code
      
      reader = new SimpleURLReader( "http://www.cs.bilkent.edu.tr/~david/housman.txt");
      System.out.println( reader.getPageContents()+"Line count is: " + reader.getLineCount());
      
   }
   
}