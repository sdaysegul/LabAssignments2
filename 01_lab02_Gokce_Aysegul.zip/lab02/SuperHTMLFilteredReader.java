import java.util.ArrayList;
/**
 * A simple Java HTMLFilteredReader class that offers more methods!
 * @author __Ay�eg�l G�k�e___
 * @version __26/02/2018__
 */
public class SuperHTMLFilteredReader extends HTMLFilteredReader
{
   // properties
   String url;
   
   // constructors
   public SuperHTMLFilteredReader(String theUrl) {
      super( theUrl);
      url = theUrl;
   }
   
   // methods
   
   /**
    * A method to see the percentage in increase
    * @return increase as percentage
    */ 
   public int percentage() {
      double scale;
      scale = getUnfilteredPageContents().length()/getPageContents().length();
      return (int)(( scale -1)*100);
   }
   
   /**
    * A method to get links in content
    * @return an arrayList of links
    */ 
   public ArrayList<String> getLinks() {
      int previous = -6;
      int quotation = 0;
      String content = getUnfilteredPageContents();
      ArrayList<String> links = new ArrayList<String>();
      do{
         previous = content.indexOf( "href=", previous + 6) ;
         quotation = content.indexOf( "\"", previous+6);
         if ( previous > -1)
            links.add( content.substring( previous + 6, quotation));
      } while (previous > -1);
      return links;
   }
   
   
   
   public static void main( String[] args)
   {
      
      // variables
      SuperHTMLFilteredReader reader;
      
      // program code
      
      reader = new SuperHTMLFilteredReader( "http://www.cs.bilkent.edu.tr/~david/index.html");
      System.out.println(reader.getLinks());
      
   }
}