import java.util.*;

/**
 * __Menu___ 
 * @author __Ay�eg�l G�k�e___
 * @version __26/02/2018__
 */ 
public class Menu
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner(System.in);
      
      // variables
      int selection;
      ArrayList<MySimpleURLReader> collection;
      String poem_url = "";
      int index;
      
      // program code
      collection = new ArrayList<MySimpleURLReader>();
      do {
         System.out.println("Please select an option:\n\n"+
                            "1.Add poem to collection\n" + 
                            "2.List all poems in the collection\n"+
                            "3.Quit\n");
         selection = scan.nextInt();
         index = 0;
         //adding to the collection
         if ( selection == 1) {
            System.out.println("Enter the url of the poem");
            poem_url = scan.next();
            if ( poem_url.indexOf("htm",poem_url.length()-4)!= -1) {
               collection.add(new SuperHTMLFilteredReader(poem_url));
            }
            else if ( poem_url.indexOf("txt", poem_url.length()-3)!= -1) {
               collection.add(new MySimpleURLReader(poem_url));
            }
         }
         //showing name of the file
         else if ( selection == 2) {
            System.out.println();
            for ( int i = 0; i < collection.size(); i++) {
               System.out.println("index is: "+ i +" name is :"+ collection.get(i).getName());
            }
            //showing the poem
            do {
               System.out.println("Please enter the index of the poem you want to view");
               index = scan.nextInt();
               System.out.println(collection.get(index).getPageContents());
            } while ( index != collection.size());
            System.out.println();
         }
         //warning
         else {
            System.err.println("Please enter a number between 1-3");
         }
      }while ( selection!=3);
      scan.close();                                  
   }
   
}