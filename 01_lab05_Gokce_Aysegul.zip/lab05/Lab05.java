import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import cs101.sosgame.SOS;

/**
 * Test class of the sos game
 * @author Ay�eg�l G�k�e
 * @version 02/04/2018
 */

public class Lab05
{
   public static void main(String[] args) 
   {
      //constants
      final int GAME_DIMENSION = 5;
      
      JFrame frame;
      frame = new JFrame("MySOSGame: v1.0");
      int dim = Integer.parseInt( JOptionPane.showInputDialog(frame, "How do you want size to be?") );
      String namePlayer1 =  JOptionPane.showInputDialog(frame, "Enter the name of the first Player.") ;
      String namePlayer2 =  JOptionPane.showInputDialog(frame, "Enter the name of the second Player.") ;
      //SOS sosGame;
      //sosGame = new SOS( GAME_DIMENSION);
      //SOS sosGame2;
      //sosGame2 = new SOS( 3);
      SOS sosGame3;
      sosGame3 = new SOS( dim);
      
      //SOSGUIPanel theGUIPanel;
      //theGUIPanel = new SOSGUIPanel(sosGame, "Me", "OnlyMe");
      
      //SOSGUIPanel theGUIPanel2;
      //theGUIPanel2 = new SOSGUIPanel(sosGame2, "Me", "OnlyMe");
      
      SOSGUIPanel theGUIPanel3;
      theGUIPanel3 = new SOSGUIPanel(sosGame3, namePlayer1, namePlayer2);
      
      
      //testFrame.setSize(320, 375);
      frame.setLayout( new GridLayout( 1, 0, 25, 0));
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //frame.add(theGUIPanel);
      //frame.add(theGUIPanel2);
      frame.add(theGUIPanel3);
      frame.pack(); 
      frame.getContentPane().setBackground( Color.BLACK);
      //testFrame.setBackground( new Color(0,0,0));
           
      frame.setVisible(true);
   }
}