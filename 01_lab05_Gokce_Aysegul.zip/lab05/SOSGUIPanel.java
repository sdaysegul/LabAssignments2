import cs101.sosgame.SOS;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A class of game pael
 * @author Ay�eg�l G�k�e
 * @version 02/04/2018
 */

public class SOSGUIPanel extends JPanel
{
   //properties
   SOSCanvas canvas;
   SOS game;
   
   JRadioButton s_button;
   JRadioButton o_button;
   ButtonGroup button_group;
   
   String name_player1;
   String name_player2;
   JLabel label_player1;
   JLabel label_player2;
   JPanel panel_inf;
   
   MouseListener mouse_listener;
   
   
   //constructor
   public SOSGUIPanel( SOS aGame, String thePlayer1, String thePlayer2) {
      game = aGame;
      canvas = new SOSCanvas(game);
      
      //buttons for S and O
      s_button = new JRadioButton("S");
      o_button = new JRadioButton("O");
      button_group = new ButtonGroup();
      button_group.add(s_button);
      button_group.add(o_button);
      s_button.setSelected(true);
      
      
      mouse_listener = new MyMouseListener();
      canvas.addMouseListener( mouse_listener);
      
      //player name and scores label
      name_player1 = thePlayer1;
      name_player2 = thePlayer2;
      label_player1 = new JLabel( "   " + name_player1 + "-> " + game.getPlayerScore1());
      label_player2 = new JLabel( "   " + name_player2 + "-> " + game.getPlayerScore2());
      //label_player2 = new JLabel(  game.getPlayerScore2() + " <-" + thePlayer2 );
      //label_player1.setBackground(new Color(153, 255, 153));
      //label_player2.setBackground(new Color(224, 224, 224));
      label_player1.setOpaque(true);
      label_player2.setOpaque(true);
      
      
      setLayout( new BorderLayout());
      add( canvas);
      
      panel_inf = new JPanel();
      panel_inf.setLayout( new GridLayout(1, 0));
      panel_inf.add( label_player1);
      panel_inf.add( s_button);
      panel_inf.add( o_button);
      panel_inf.add( label_player2);
      
      add( panel_inf, BorderLayout.SOUTH);
      setPreferredSize( new Dimension(301, 330));
      setBackground( Color.BLACK);
      setOpaque( true);
      
   }
   @Override protected void paintComponent(Graphics g)
   {
      super.paintComponent(g);
      setBackground(Color.BLACK);
      setOpaque( true);
   }
   
   public class MyMouseListener extends MouseAdapter {
      public void mouseClicked(MouseEvent event) {
         
         //understanding the point is in which cell
         int x = (event.getX() / canvas.cellSize);      
         int y = (event.getY() / canvas.cellSize);         
         
         
         char currentLetter;
         if (s_button.isSelected()) {
            currentLetter = 's';
         }
         else {
            currentLetter = 'o';
         }
         
         game.play( currentLetter, y + 1, x + 1);
         repaint();
          //changing background color evry turn changed
         if (game.getTurn() == 1) {
            label_player1.setText( "   " + name_player1 + "--> " + game.getPlayerScore1());
            label_player1.setBackground(new Color(204, 0, 102));
            label_player2.setBackground(new Color(240, 240, 240));
         }
         else {
            label_player2.setText( "   " + name_player2 + "--> " + game.getPlayerScore2());
            label_player2.setBackground(new Color(204, 0, 102));
            label_player1.setBackground(new Color(240, 240, 240));
         }
         repaint();
          //information box about result of the game
         if (game.isGameOver()) {
            if (game.getPlayerScore1() > game.getPlayerScore2()) {
               JOptionPane.showMessageDialog(null, name_player1 + " won!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (game.getPlayerScore2() > game.getPlayerScore1()) {
               JOptionPane.showMessageDialog(null, name_player2 + " won!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
            else if (game.getPlayerScore1() == game.getPlayerScore2()) {
               JOptionPane.showMessageDialog(null, "It is a draw!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            }
         }  
      }
   }
   
}