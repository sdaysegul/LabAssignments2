import cs101.sosgame.SOS;
import javax.swing.*;
import java.awt.*;

/**
 * A class of the game board
 * @author Ay�eg�l G�k�e
 * @version 02/04/2018
 */

public class SOSCanvas extends JPanel
{
   //properties
   SOS game;
   int dimension;
   int borderSize = 300;
   int cellSize;
   //constructor
   public SOSCanvas( SOS aGame) {
      super();
      game = aGame;
      dimension = game.getDimension();
      cellSize = borderSize / dimension;
      setPreferredSize( new Dimension(borderSize , borderSize));
   }
   
   //methods
   
   @Override
   protected void paintComponent( Graphics g) {
      super.paintComponent(g);
      setBackground(Color.BLACK);
      g.drawRect( 0 , 0 , borderSize, borderSize);
      for( int i = 0; i < dimension; i++){
         for( int j = 0; j < dimension; j++){
            g.setColor(new Color( 240, 240, 240)); // background color
            g.drawRect( i * cellSize, j * cellSize, cellSize, cellSize); // creating the cells
            g.drawString( "" + game.getCellContents( j , i), (cellSize/2) + ( i * cellSize), ((cellSize/2) + ( j * cellSize))); // putting the string into the center
         }
      }
   }
}