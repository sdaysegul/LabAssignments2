package shapes;

/**
 * An interface that is specifically designed for graphics and to draw.
 * @author  Ay�eg�l G�k�e
 * @version 26.03.2018
 */
import java.awt.Graphics;

public interface Drawable
{
   /**
    * An interface method that draws.
    * @param g - graphics parameter
    */
   void draw(Graphics g);
}