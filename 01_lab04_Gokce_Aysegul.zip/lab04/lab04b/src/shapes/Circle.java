package shapes;

/**
 * A class that extends the Shape class as a circle and implements the 
 * Selectable interface.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */
public class Circle extends Shape implements Selectable
{
   // properties
   public int radius;
   private boolean selected;
   
   // constructors
   
   /**
    * Constructs a circle with given radius, x coordinate and y coordinate.
    * @param radius - the radius of the circle
    * @param tempX - the x coordinate
    * @param tempY - the y coordinate
    */
   public Circle (int radius, int tempX, int tempY)
   {
      this.radius = radius;
      x = tempX;
      y = tempY;
      selected = false;
   }
   
   // methods
   
   /**
    * A method that returns the state of the current shape.
    * @return selected - state
    */
   public boolean getSelected()
   {
      return selected;
   }
   
   /**
    * A method that sets the state to true.
    * @param s - current state
    */
   public void setSelected(boolean s)
   {
      selected = s;
   }
   
   /**
    * A method that returns the Shape given within the x and y coordinates.
    * @param x - x coordinate
    * @param y - y coordinate
    * @return the selected shape
    */
   public Shape contains(int x, int y)
   {
      double distance = Math.sqrt(Math.pow(Math.abs(this.getX() - x), 2) 
                                  + Math.pow(Math.abs(this.getY() - y), 2));
      
      if (distance <= radius)
      {
         return this;
      }
      else
         return null;
         
   }
   
   /**
    * A method that returns the area of the circle.
    * @return the area
    */
   public double getArea()
   {
      return Math.PI * Math.pow(radius, 2);
   }
   
   /**
    * A method return the circle's information as a string.
    * @return the string of the shape
    */
   public String toString()
   {
      return String.format("This is a circle: %n"
                          + "\tselected: %b %n"
                          + "\tradius: %d %n"
                          + "\tarea: %.2f %n"
                          + "\tx coordinate of center of the circle: %d %n"
                          + "\ty coordinate of center of the circle: %d", 
                          this.getSelected(), this.radius, this.getArea(), x, y);
   }
}
