package shapes;

/**
 * An interface that is specifically designed for x and y coordinates.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public interface Locatable
{
   /**
    * An interface method that returns the x coordinate.
    * @return the x coordinate
    */
   int getX();
   
   /**
    * An interface method that returns the y coordinate.
    * @return the y coordinate
    */
   int getY();
   
   /**
    * An interface method that sets the location.
    * @param x - x coordinate
    * @param y - y coordinate
    */
   void setLocation(int x, int y);
}
