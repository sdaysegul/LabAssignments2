package shapes;

/**
 * An interface that is specifically designed for x and y coordinates.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public interface Selectable
{
   /**
    * An interface method that returns state of the shape.
    * @return true if it is selected
    */
   boolean getSelected();
   
   /**
    * An interface method that sets the state of the shape.
    * @param current state
    */
   void setSelected(boolean s);
   
   /**
    * An interface method that returns the shape that the x and y coordinates are within.
    * @param x - x coordinate
    * @param y - y coordinate
    * @return the shape
    */
   Shape contains(int x, int y);
}
