package shapes;

/**
 * An abstract class shape that implements Locatable interface and defines various shapes.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public abstract class Shape implements Locatable
{
   // properties
   public int x;
   public int y;
   
   // constructors
   
   // methods
   
   /**
    * A method that returns the x coordinate.
    * @return x - the x coordinate
    */
   public int getX()
   {
      return x;
   }
   
   /**
    * A method that returns the y coordinate.
    * @return y - the y coordinate
    */   
   public int getY()
   {
      return y;
   }
   
   /**
    * A method that sets the location to a specific place.
    * @param x - x coordinate
    * @param y - y coordinate
    */
   public void setLocation(int x, int y)
   {
      this.x = x;
      this.y = y;
   }
   
   /**
    * An abstract method that returns the area of certain shape.
    * @return the area
    */
   public abstract double getArea();
   
   
}
