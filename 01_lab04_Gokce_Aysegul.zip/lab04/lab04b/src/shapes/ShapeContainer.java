package shapes;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class that contains an arraylist of shapes.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public class ShapeContainer implements Iterable
{
   // properties
   ArrayList<Shape> shapes;
   
   // constructors
   
   /**
    * Constructs an empty arraylist of shapes.
    */
   public ShapeContainer()
   {
      shapes = new ArrayList<Shape>();
   }
   
   // methods
   
   /**
    * A method that adds a shape into the list.
    * @param s - shape
    */
   public void add(Shape s)
   {
      shapes.add(s);
   }
   
   /**
    * A method that returns the total surface area of all the shapes in the list.
    * @return the total surface area
    */
   public double getArea()
   {
      int tmp = 0;
      for (int i = 0; i < shapes.size(); i++)
      {
         tmp += shapes.get(i).getArea();
      }
      return tmp;
   }
   
   /**
    * A method that returns the string version of the information of the shapes.
    * @return the string of the shapes
    */
   public String toString()
   {
      String str = "";
      for (int i = 0; i < shapes.size(); i++)
      {
         str += shapes.get(i).toString() + "\n";
      }
      return str;
   }
   
   /**
    * A method that returns the shape that the x and y coordinates contain and changes it's state.
    * @param x - x coordinate
    * @param y - y coordinate
    * @return the first shape that is found
    */
   public Shape find(int x, int y)
   {
      for (int i = 0; i < shapes.size(); i++)
      {
         if (((Selectable)shapes.get(i)).contains(x, y) != null)
         {
            boolean shapeState = (((Selectable)shapes.get(i)).getSelected());
            ((Selectable)shapes.get(i)).setSelected(!shapeState);
            return shapes.get(i);
         }    
      }
      return null;
   }
   
   /**
    * A method that removes the selected shapes from the list.
    */
   public void removeSelected()
   {
      for (int i = shapes.size() - 1; i >= 0; i--)
      {
         if (((Selectable)shapes.get(i)).getSelected())
            shapes.remove(i);
      }
   }
   
   /**
    * A method that returns the number of shapes in the container.
    * @return the number of shapes in the container
    */
   public int size()
   {
      return shapes.size();
   }
 
   /**
    * A method that returns the number of shapes found at the point x,y 
    * and sets the selected property of those shapes to true.
    * @return number of shapes found at the point x,y
    */
   public int selectAllAt(int x, int y)
   {
      int numOfShapes = 0;
      for (int i = 0; i < shapes.size(); i++)
      {
         if (((Selectable)shapes.get(i)).contains(x, y) != null)
         {
            numOfShapes++;
            boolean shapeState = (((Selectable)shapes.get(i)).getSelected());
            ((Selectable)shapes.get(i)).setSelected(!shapeState);
         }
      }
      return numOfShapes;
   }
   
   // ShapeIterator inner class------------------------------------------
   
   /**
    * A ShapeIterator inner class that implements Iterator.
    */
   class ShapeIterator implements Iterator
   {
      // properties
      ShapeContainer aContainer;
      int index;
   
      // constructors
      
      /**
       * Constructs a container of shapes as an iterator.
       * @param aContainer - an ShapeContainer object
       */
      public ShapeIterator(ShapeContainer aContainer)
      {
         this.aContainer = aContainer;
         index = 0;
      }
   
      // methods
      
      /**
       * Returns the next element in the iteration.
       * @return the next element in the iteration
       */
      public Object next() 
      {
         return shapes.get(index++);
      }
   
      /**
       * Returns true if the iteration has more elements.
       * @return true if the iteration has more elements
       */
      public boolean hasNext()
      {
         return index < aContainer.size();
      }
   }
   //------------------------------------------------------------------------
   
   /**
    * A method that returns an iterator over a set of elements
    * @return an Iterator
    */
   public Iterator iterator()
   {
      return new ShapeIterator(this);
   } 
}