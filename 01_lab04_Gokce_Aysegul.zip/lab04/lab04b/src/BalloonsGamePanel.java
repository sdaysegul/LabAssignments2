import java.awt.*;
import javax.swing.*;
import shapes.ShapeContainer;
import java.awt.event.*;

/**
 * A class that creates a balloon game panel and extends the JPanel class.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public class BalloonsGamePanel extends JPanel
{
   // constants
   final int TIME_OUT = 360;
   
   // properties
   ShapeContainer balloons;
   Timer t;
   int points;
   JLabel score;
   int elapsedTime;
   
   // constructors
   
   /**
    * Constructs a panel with balloons that grow and get removed when clicked.
    */
   public BalloonsGamePanel()
   {
      balloons = new ShapeContainer();
      points = 0;
      score = new JLabel("Score: " + points);
      score.setForeground(Color.YELLOW);
      add(score);
      elapsedTime = 0;
      setSize(new Dimension(700, 700));
      setBackground(new Color(0, 0, 0)); // (int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255) ));
      
      t = new Timer(60, new TimerListener());
                       
      for (int i = 1; i < 26; i++)
      {
         balloons.add(new Balloon((int) (Math.random() * getWidth()), 
                                  (int) (Math.random() * getHeight())));  
      }
      addMouseListener(new MyMouseListener());
      t.start();
   }
   
   // methods
   
   /**
    * A method that resets the game.
    */
   private void reset() 
   {
      balloons = new ShapeContainer();
      elapsedTime = 0;
      points = 0;
      
      for (int i = 1; i < 26; i++)
      {
         balloons.add(new Balloon((int) (Math.random() * getWidth()), 
                                  (int) (Math.random() * getHeight())));  
      }
   }
   
   /**
    * A method that overrides the parent method of paintComponent and 
    * draws balloon on the panel.
    * @param g - the Graphics parameter
    */
   public void paintComponent(Graphics g)
   {
      super.paintComponent(g);
      for (Object s: balloons)
      {
         ((Balloon) s).draw(g);
      }
   }
   
   // TimerListener inner class------------------------------------------------
   
   /**
    * A TimerListener inner class that implements ActionListener.
    */
   class TimerListener implements ActionListener
   {
      /**
       * A method that performs a specific action.
       * @param event - the event that will happen
       */
      public void actionPerformed(ActionEvent event) 
      {
         for (Object s: balloons)
         {
            Balloon b = (Balloon) s;
            b.grow();
         }
         balloons.removeSelected();
         if (balloons.size() < 15)
            balloons.add(new Balloon((int) (Math.random() * getWidth()), 
                                     (int) (Math.random() * getHeight())));
         elapsedTime++;
         if (elapsedTime >= TIME_OUT) 
         {
            int option = JOptionPane.showConfirmDialog(null, "Play again?",
                                                       "Game Over!",
                                                       JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION)
            {
               reset();
            }
            else if (option == JOptionPane.NO_OPTION)
            {
               System.exit(0);
            } 
         }
         repaint();
      }
   }
   /**
    * A MyMouseListener inner class that implements MouseListener.
    */
   class MyMouseListener implements MouseListener
   {
      /**
       * An overriden method that performs an event when the mouse is pressed.
       * @param e - the event that will happen
       */
      public void mousePressed(MouseEvent e)
      {
         if (balloons.selectAllAt(e.getX(), e.getY()) >= 2)
         {
            points++;
            score.setText("Points: " + points);
         }
      }
         
      public void mouseExited(MouseEvent e)
      {
            
      }
         
      public void mouseEntered(MouseEvent e)
      {
            
      }
      public void mouseClicked(MouseEvent e)
      {
            
      }
      public void mouseReleased(MouseEvent e)
      {
            
      }
   }   
}