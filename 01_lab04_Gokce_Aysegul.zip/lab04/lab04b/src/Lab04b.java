import javax.swing.*;
import java.awt.*;

/**
 * A class that creates a balloon game.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public class Lab04b
{
   public static void main(String[] args)
   {
      // constants
      final int FRAME_WIDTH = 800;
      final int FRAME_HEIGHT = 800;
      
      // variables
      JFrame frame;
      BalloonsGamePanel balloonPanel;
      
      // program code
      frame = new JFrame();
      frame.setLayout(new BorderLayout());
      balloonPanel = new BalloonsGamePanel();
      frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
      frame.add(balloonPanel);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
      
   }
}