import shapes.Circle;
import shapes.Drawable;
import java.awt.*;

/**
 * A class that extends the Circle class as a balloon and implements the 
 * Drawable interface.
 * @author Ay�eg�l G�k�e
 * @version 26.03.2018
 */

public class Balloon extends Circle implements Drawable
{
   // properties
   
   // constructors
   
   /**
    * Constructs a balloon with fixed radius, x coordinate and y coordinate.
    * @param tempX - the x coordinate
    * @param tempY - the y coordinate
    */
   public Balloon(int x, int y)
   {
      super(25, x, y);
   }
      
   
   // methods
   
   /**
    * A method that draws a circle with radius, x coordinate and y coordinate.
    * @param g - graphics parameter
    */
   public void draw(Graphics g)
   {
      g.drawOval(x - radius, y - radius, radius * 2, radius * 2);
      g.setColor(new Color( (int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255) ));
   }
   
   /**
    * A method that grows a circle.
    */
   public void grow() 
   {
      radius = radius + 1;
      if (radius > 100)
      {
         setSelected(true);
         radius = 0;
      }  
   }
}   