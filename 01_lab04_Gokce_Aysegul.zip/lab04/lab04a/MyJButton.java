import javax.swing.*;
import java.awt.event.*;

/**
 * __MyJButton Class extends actionListener__ 
 * @author _Ay�eg�l G�k�e___
 * @version _26.03.2018_
 */ 
public class MyJButton extends JButton implements ActionListener
{
   //proporties
   boolean hides;
   MyJLabel label;
   
   //constructor
   public MyJButton( MyJLabel theLabel) {
      hides = false;
      addActionListener(this);
      label = theLabel;
   }
   
   //methods
   public void putPrize() {
      hides = true;
   }
   
   public boolean getStatu() {
      return hides;
   }
   
   
   public static int count = 0;
   public static boolean hasWon = false;
   
   public void actionPerformed( ActionEvent e)
   {
      count++;
      label.text();
      if ( ((MyJButton)e.getSource()).getStatu() == true) {
         hasWon = true;
         setText("Prize!!");
         System.out.println( "Prize is found at " + count + " trial.");
      }
      else {
         System.out.println( "Trial --> " + count);
         setText("" + count);
      }
      
   }
   
}