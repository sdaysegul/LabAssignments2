import javax.swing.*; 
import java.awt.*;

/**
 * __MyJLabel Class that extends JLabel to make it have one more method___ 
 * @author _Ay�eg�l G�k�e___
 * @version _26.03.2018_
 */ 
public class MyJLabel extends JLabel
{
   public void text()
   {
      if ( MyJButton.hasWon) {
      setText( "Congratulations!! You found the prize at "+ MyJButton.count + " trial.");
      }
      else {
      setText( "Unfortunately!! You need to try more, so far: "+ MyJButton.count + " trial.");
      }
      System.out.println( "Paint called");
   }
}