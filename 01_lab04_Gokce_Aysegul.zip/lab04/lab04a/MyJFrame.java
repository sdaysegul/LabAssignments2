import javax.swing.*;
import java.awt.event.*;

public class MyJFrame extends JFrame
{
   //properties
   JLabel background;
   MyJLabel label;
   JPanel panel;
   JPanel buttonPanel;
   MyJButton[] buttons;
   
   //constructor
   public MyJFrame(){
      super();
      // Creating the label for messages
      setContentPane(new JLabel(new ImageIcon("C:\\Users\\User\\Desktop\\cs102\\lab04\\lab04a\\background.jpg")));
      setLayout(new BorderLayout());
      panel = new JPanel();
      panel.setLayout( new BorderLayout());
      panel.setOpaque(false);
      label = new MyJLabel();
      label.setText("kjdbsf");
      label.setHorizontalAlignment(SwingConstants.CENTER);
      label.setOpaque(false);
      
      // Creating the buttons
      buttons = new MyJButton[5];
      for ( int i = 0; i < 5; i++) {
         buttons[i] = new MyJButton();
         buttons[i].setBackground( new Color( 255, (132 + 17*i), (132 + 17*i)));
         //buttons[i].addActionListener( new MyActionListener());
      }
      
      buttons[(int)(Math.random() * 5)].putPrize();
      
      
      // Creating the panel for buttons
      buttonPanel = new JPanel();
      buttonPanel.setLayout( new GridLayout( 1, 0) );
      buttonPanel.setPreferredSize(new Dimension(150, 125));
      for ( int i = 0; i < 5; i++) {
         buttonPanel.add(buttons[i]);
      }
      
      //Filling the content
      panel.add( label, BorderLayout.CENTER);
      panel.add( buttonPanel, BorderLayout.PAGE_END);
      
      // Creating the frame and filling it      
      add(panel, BorderLayout.CENTER);
      setSize( 700, 500 );
      setBackground( new Color( 255, 255, 255)); //200, 250, 255 ));
      //JLabel background=new JLabel(new ImageIcon("C:\\Users\\Computer\\Downloads\\background.jpg"));
      //frame.add(background);
      setVisible(true);
   }
   
}