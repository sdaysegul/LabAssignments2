import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;
/**
 * __Button Game__ 
 * @author _Ay�eg�l G�k�e___
 * @version _26.03.2018_
 */ 
public class ButtonGame 
{ 
   MyActionListener2 actionlistener;
   
   public static void main( String[] args)
   {
      JFrame frame;
      JLabel background;
      MyJLabel label;
      JPanel panel;
      JPanel buttonPanel;
      MyJButton[] buttons;
      
      // Creating the label for messages
      
      
      frame = new JFrame();
      frame.setContentPane(new JLabel(new ImageIcon("H:\\private\\cs102\\lab04\\lab04a\\background.jpg")));
      frame.setLayout(new BorderLayout());
      panel = new JPanel();
      panel.setLayout( new BorderLayout());
      panel.setOpaque(false);
      label = new MyJLabel();
      label.setText("Game" );
      label.setHorizontalAlignment(SwingConstants.CENTER);
      label.setOpaque(false);
      
      // Creating the buttons
      buttons = new MyJButton[25];
      for ( int i = 0; i < 25; i++) {
         buttons[i] = new MyJButton( label);
         buttons[i].setText("?");
         buttons[i].setBackground( new Color( 255,  (82 + 7*i), (82 + 7*i)));
         //buttons[i].addActionListener( new MyActionListener2() );
      }
      
      buttons[(int)(Math.random() * 25)].putPrize(); 
      
      // Creating the panel for buttons
      buttonPanel = new JPanel();
      buttonPanel.setLayout( new GridLayout( 0, 5) );
      buttonPanel.setPreferredSize(new Dimension(150, 300));
      for ( int i = 0; i < 25; i++) {
         buttonPanel.add(buttons[i]);
      }
      
      //Filling the content
      panel.add( label, BorderLayout.CENTER);
      panel.add( buttonPanel, BorderLayout.PAGE_END);
      
      // Creating the frame and filling it      
      frame.add(panel, BorderLayout.CENTER);
      frame.setSize( 700, 400 );
      frame.setBackground( new Color( 255, 255, 255)); //200, 250, 255 ));
      //JLabel background=new JLabel(new ImageIcon("C:\\Users\\Computer\\Downloads\\background.jpg"));
      //frame.add(background);
      frame.setVisible(true);
      
   }
   
   public class MyActionListener2 implements ActionListener
   {
      public void actionPerformed( ActionEvent e)
      {
            System.out.println( "from inner class" );
         
      }
      
   }
   
   
}