import java.awt.event.*;
/**
 * _____ 
 * @author _Ay�eg�l G�k�e___
 * @version _26.03.2018_
 */ 

public class MyActionListener implements ActionListener
{
   public void actionPerformed( ActionEvent e)
   {
      if ( ((MyJButton)e.getSource()).getStatu() == true)
         System.out.println( "Prize is found");
      
      else {
         System.out.println( "trial" );
      }
      
   }

}