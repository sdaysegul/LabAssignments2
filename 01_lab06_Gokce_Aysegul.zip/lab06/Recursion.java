import java.util.Scanner;
import java.util.ArrayList;

/**
 * __Some recursion methods___ 
 * @author __Ay�eg�l G�k�e___
 * @version __16.04.2018__
 */ 
public class Recursion
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      
      // testing the methods
      
      String test = "eelifedeneme";
      System.out.println( eCounter(test) );
      
      int test2 =27;
      System.out.println( binary(test2) );
      
      ArrayList<String> test3 = new ArrayList<String>();
      test3.add("abc");
      test3.add("def");
      test3.add("gh�");
      if ( isOrdered(test3, 3))
         System.out.println("ordered");
      
      enumerate( 3 );
      
      int[] arr = {111, 24, 15, 7};
      
      if ( isSubsetSum(arr, 4, 31))
         System.out.println("works");
      
      
   }
   
   /**
    * A method that count the number of 'e' in a string
    * @param s is teh string we are looking for in
    * @return int count of 'e'
    */ 
   public static int eCounter( String s){
      if ( s.length() > 0 ) {
         if ( s.charAt(s.length()-1 ) == 'e' ) {
            return 1 + eCounter( s.substring(0, s.length()-1));
         }
         else
            return eCounter( s.substring(0, s.length()-1));
      }
      else
         return 0;
   }
   
   
   /**
    * A method that returns the number into the binary system
    * @param number is the number tht will change
    * @return String the binary version of the number
    */ 
   public static String binary( int number){
      if( number > 1)
         return binary( number/2) + (number % 2) + "";
      else
         return "1";
   }
   
   
   /**
    * A method that 
    * @param list is the array list we are checking
    * @param size is the number of the elements we are checking
    * @return String the binary version of the number
    */ 
   public static boolean isOrdered( ArrayList<String> list, int size){
      if( size > 1) {
         if( list.get(size-1).compareTo(list.get(size-2)) > 0)
            return isOrdered( list, size-1);
         else
            return false;
      }
      else 
         return true;
   }
   
   
   /**
    * A method that uses enamurates method to generate numbers starting from the first possible number
    * @param n is the digit number
    */ 
    public static void enumerate( int n) {
       enumerateHidden(  n ,(int) Math.pow( 10 , n-1) );
    }
   
   /**
    * A method that Enumerates the numbers beginning from the number
    * @param n is the digit number
    * @param number is tha starting value
    */ 
   public static void enumerateHidden(int n, int number) {
      if ( number < Math.pow(10,n)) // putting the limit of the numbers
      {
         if ( check( number)) {
            System.out.println(number);
         }
         enumerateHidden( n, (number+2));
      }
      
   }
   
   /**
    * A method that checks if the number is okay for the enumerate method
    * @param theNumber is the number we are checking
    * @return true if it is valid or false if it's not
    */ 
   public static boolean check(int theNumber){
      String number = "" + theNumber;
      if ( theNumber > 9 ){
            return ( number.charAt( number.length() -1) > number.charAt( number.length() -2) && check( theNumber/10));
         }
      else {
         return true;
      }
   }
   
   public static boolean isSubsetSum(int set[], int n, int sum) {
      // If number was found
       if (sum == 0)
         return true;
       
       //If reached end of set
       if ( n == 0 && sum != 0)
         return false;
      
       // If last element is greater than sum, then ignore it
       if ( set[ n - 1] > sum)
         return isSubsetSum(set, n - 1, sum);
      
       // 2 cases, either last element is the target OR is included in the sum
       return isSubsetSum(set, n - 1, sum) || isSubsetSum( set, n - 1, sum - set[ n - 1]);
    }
   
}